package com.ecommerce;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class QueryServletDemo extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		

		Connection connection = null;
		try {
			
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommercedb", "root", "Grkm@2168");
		    

			Statement statement = connection.createStatement();

			ResultSet resultSet = statement.executeQuery("SELECT * FROM productlist");

			out.println("QUERY RESULTS:<br><br>");
			out.println("<table border=1>");
			out.println("<tr><th>ID<th> NAME <th>PRICE<th> </tr>");
			
			while (resultSet.next()) {
				
				long ID = resultSet.getLong("ID");
				String name = resultSet.getString("name");
				float price = resultSet.getFloat("price");
				

				out.printf("<tr><td> %s <td>%s <td>%s </tr>",ID , name ,price);
			}

		} catch (SQLException e) {
			out.println(e);
		}

		out.close();

	}

}