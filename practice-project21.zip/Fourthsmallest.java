package basic;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Fourthsmallest {
	
	    public static void main(String[] args) {
	        List<Integer> numbers = new ArrayList<>();
	        numbers.add(7);
	        numbers.add(5);
	        numbers.add(3);
	        numbers.add(2);
	        numbers.add(8);
	        numbers.add(6);
	        numbers.add(4);

	        Integer fourthsmallest = findFourthsmallest(numbers);
	        System.out.println("Fourth smallest number is: " + fourthsmallest);
	    }

	    public static Integer findFourthsmallest(List<Integer> numbers) {
	        if (numbers == null || numbers.size() < 4) {
	            throw new IllegalArgumentException("Invalid input");
	        }

	        // Sort the list in ascending order
	        Collections.sort(numbers);

	        // The fourth smallest number is now at index 3
	        return numbers.get(3);
	    }
	}
	        

