package basic;

public class Linearsearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 10, 20, 30, 23, 40, 50, 77 };

		int key = 30;

		int positionOfKey = doLinearSearch(arr, key);

		if (positionOfKey != -1)
			System.out.println("Found the key " + key + " at position " + positionOfKey);
		else
			System.out.println("Key " + key + " not found ");

		key = 22;

		positionOfKey = doLinearSearch(arr, key);

		if (positionOfKey != -1)
			System.out.println("Found the key " + key + " at position " + positionOfKey);
		else
			System.out.println("Key " + key + " not found ");

	}

	private static int doLinearSearch(int[] arr, int key) {
		int positionOfKey = -1;

		for (int i = 0; i < arr.length; i++) {

			if (arr[i] == key) {
				positionOfKey = i;
				break;
			}
		}

		return positionOfKey;

	}

	

}
