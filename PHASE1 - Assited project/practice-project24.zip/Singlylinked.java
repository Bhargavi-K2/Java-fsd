package basic;

import java.util.Scanner;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    void addElement(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node last = head;
            while (last.next != null) {
                last = last.next;
            }
            last.next = newNode;
        }
    }

    void deleteElement(int key) {
        if (head == null) {
            return;
        }
        if (head.data == key) {
            head = head.next;
            return;
        }
        Node current = head;
        while (current.next != null) {
            if (current.next.data == key) {
                current.next = current.next.next;
                return;
            }
            current = current.next;
        }
    }

    void displayList() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}

public class  Singlylinked {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter number of elements: ");
        int n = scanner.nextInt();
        System.out.println("Enter the elements: ");
        for (int i = 0; i < n; i++) {
            int value = scanner.nextInt();
            list.addElement(value);
        }

        System.out.println("Linked list: ");
        list.displayList();

        System.out.println("Enter the key to be deleted: ");
        int key = scanner.nextInt();
        list.deleteElement(key);

        System.out.println("Linked list after deletion of " + key + ": ");
        list.displayList();
    }
}


		     
