package basic;

public class Method {
	
	    public static void main(String[] args) {
	        int x = 10;
	        System.out.println("Before call by value: " + x);
	        callByValue(x);
	        System.out.println("After call by value: " + x);

	        MyClass obj = new MyClass();
	        obj.value = 20;
	        System.out.println("Before call by reference: " + obj.value);
	        callByReference(obj);
	        System.out.println("After call by reference: " + obj.value);
	    }

	    public static void callByValue(int value) {
	        value = 30;
	    }

	    public static void callByReference(MyClass obj) {
	        obj.value = 40;
	    }
	}

	class MyClass {
	    int value;
	}

