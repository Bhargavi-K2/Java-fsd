package basic;

import java.util.LinkedList;

public class Circularlinked {
	
	    public static void main(String[] args) {
	        LinkedList<Integer> list = new LinkedList<>();
	        list.add(10);
	        list.add(20);
	        list.add(30);
	        list.add(40);

	        System.out.println("Linked List before insertion: " + list);

	        insertElement(list, 25);

	        System.out.println("Linked List after insertion: " + list);
	    }

	    public static void insertElement(LinkedList<Integer> list, int value) {
	        if (list.isEmpty()) {
	            list.add(value);
	            return;
	        }

	        Integer first = list.get(0);
	        Integer last = list.get(list.size() - 1);

	        if (value >= first || value <= last) {
	            list.add(value);
	            return;
	        }

	        for (int i = 0; i < list.size(); i++) {
	            if (list.get(i) > value && list.get((i + 1) % list.size()) < value) {
	                list.add(i + 1, value);
	                return;
	            }
	        }
	    }
	}


