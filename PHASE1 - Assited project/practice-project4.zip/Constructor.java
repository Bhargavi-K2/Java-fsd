package basic;

public class Constructor {
	
	    public static void main(String[] args) {
	        Constructor[] instances = {
	                new DefaultConstructor(),
	                new ParametrizedConstructor(1),
	                new CopyConstructor(new ParametrizedConstructor(2)),
	                new StaticFactoryMethod()
	        };

	        for (Constructor instance : instances) {
	            System.out.println(instance);
	        }
	    }

	    // Default constructor
	    public Constructor() {
	        System.out.println("Default constructor called.");
	    }

	    // Parametrized constructor
	    public Constructor(int i) {
	        System.out.println("Parametrized constructor called with value: " + i);
	    }

	    // Copy constructor
	    public Constructor(Constructor other) {
	        System.out.println("Copy constructor called with value: " + other.getVal());
	    }

	    // Static factory method
	    public static Constructor staticFactoryMethod() {
	        System.out.println("Static factory method called.");
	        return new Constructor();
	    }

	    public int getVal() {
	        return 0;
	    }

	    public static class DefaultConstructor extends Constructor {
	        // Default constructor
	        public DefaultConstructor() {
	            super();
	        }
	    }

	    public static class ParametrizedConstructor extends Constructor {
	        private int val;

	        // Parametrized constructor
	        public ParametrizedConstructor(int val) {
	            super(val);
	            this.val = val;
	        }

	        @Override
	        public int getVal() {
	            return val;
	        }
	    }

	    public static class CopyConstructor extends Constructor {
	        // Copy constructor
	        public CopyConstructor(Constructor other) {
	            super(other);
	        }
	    }

	    public static class StaticFactoryMethod extends Constructor {
	        // Private constructor
	        private StaticFactoryMethod() {
	            super();
	        }

	        // Static factory method
	        public static StaticFactoryMethod staticFactoryMethod() {
	            return new StaticFactoryMethod();
	        }
	    }
	}




