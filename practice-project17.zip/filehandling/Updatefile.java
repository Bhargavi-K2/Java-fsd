package filehandling;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Updatefile {
    public static void main(String[] args) {
        String fileName = "testFile.txt";

        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;
            StringBuilder updatedText = new StringBuilder();
            while ((line = bufferedReader.readLine()) != null) {
                updatedText.append(line.replace("text", "updated text")).append("\n");
            }
            bufferedReader.close();

            FileWriter fileWriter = new FileWriter(fileName);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(updatedText.toString());
            bufferedWriter.close();

        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}



