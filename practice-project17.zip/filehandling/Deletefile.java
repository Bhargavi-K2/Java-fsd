package filehandling;
import java.io.File;
import java.io.IOException;

public class Deletefile {

	    public static void main(String[] args) {
	        String fileName = "testFile.txt";

	        try {
	            File myObj = new File(fileName);
	            if (myObj.delete()) {
	                System.out.println("File deleted: " + myObj.getName());
	            } else {
	                System.out.println("File does not exist or could not be deleted.");
	            }
	        } catch (SecurityException e) {
	            System.out.println("An error occurred.");
	            e.printStackTrace();
	        }
	    }
	}


